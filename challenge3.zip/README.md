#### Route /album?album_id={album id} return Images for album of id specied

